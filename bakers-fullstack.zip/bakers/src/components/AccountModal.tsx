import { useEffect, useState } from "react";
import ModalShell from "@/components/ModalShell";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/lib/supabaseClient";

interface Props {
  open: boolean;
  onClose: () => void;
}

interface OrderRow {
  id: number;
  total: number;
  status: string;
  created_at: string;
}

export default function AccountModal({ open, onClose }: Props) {
  const { user, signIn, signUp, signOut, isSupabaseConfigured } = useAuth();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [orders, setOrders] = useState<OrderRow[]>([]);

  useEffect(() => {
    if (user && supabase) {
      supabase
        .from("orders")
        .select("id,total,status,created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .then(({ data }) => setOrders((data as OrderRow[]) ?? []));
    }
  }, [user]);

  async function handleSubmit() {
    if (!isSupabaseConfigured) {
      setMessage({ type: "err", text: "Accounts aren't connected yet — Supabase needs to be set up first." });
      return;
    }
    if (!email || !password) {
      setMessage({ type: "err", text: "Enter an email and password." });
      return;
    }
    const result = mode === "login" ? await signIn(email, password) : await signUp(email, password);
    if (result.error) {
      setMessage({ type: "err", text: result.error });
    } else {
      setMessage({
        type: "ok",
        text: mode === "login" ? "Logged in!" : "Account created! Check your email if confirmation is required.",
      });
    }
  }

  return (
    <ModalShell open={open} onClose={onClose}>
      {!user ? (
        <>
          <div className="flex gap-2 mb-5">
            {(["login", "signup"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`flex-1 py-2.5 rounded-xl text-sm font-semibold border transition-colors ${
                  mode === m ? "bg-espresso text-cream border-espresso" : "border-espresso/15 text-espresso/60"
                }`}
              >
                {m === "login" ? "Log In" : "Sign Up"}
              </button>
            ))}
          </div>

          {message && (
            <div
              className={`text-sm rounded-lg px-3 py-2.5 mb-4 ${
                message.type === "ok" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
              }`}
            >
              {message.text}
            </div>
          )}

          <div className="space-y-3.5 mb-5">
            <div>
              <label className="block text-xs font-semibold text-espresso/60 mb-1.5">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@email.com"
                className="w-full px-3.5 py-3 rounded-xl border border-espresso/15 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-espresso/60 mb-1.5">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-3 rounded-xl border border-espresso/15 text-sm"
              />
            </div>
          </div>

          <button
            onClick={handleSubmit}
            className="w-full bg-espresso text-cream rounded-full py-3.5 font-semibold text-sm hover:bg-berry transition-colors"
          >
            {mode === "login" ? "Log In" : "Sign Up"}
          </button>
          <p className="text-xs text-espresso/50 mt-3.5">
            Signing in lets you save your address and view past orders. Not required to place an order.
          </p>
        </>
      ) : (
        <>
          <h3 className="font-display font-bold text-xl mb-1">Your Account</h3>
          <p className="text-sm text-espresso/60 mb-5">{user.email}</p>
          <h4 className="text-xs font-bold uppercase tracking-wide mb-2">Order History</h4>
          {orders.length === 0 ? (
            <p className="text-sm text-espresso/50">No orders yet.</p>
          ) : (
            <div className="space-y-0 mb-2">
              {orders.map((o) => (
                <div key={o.id} className="flex justify-between text-sm py-2.5 border-b border-espresso/10">
                  <span>₹{o.total} · {o.status}</span>
                  <span className="text-espresso/50">{new Date(o.created_at).toLocaleDateString()}</span>
                </div>
              ))}
            </div>
          )}
          <button
            onClick={signOut}
            className="w-full mt-5 border-[1.5px] border-espresso rounded-full py-3.5 font-semibold text-sm hover:bg-espresso hover:text-cream transition-colors"
          >
            Log Out
          </button>
        </>
      )}
    </ModalShell>
  );
}
