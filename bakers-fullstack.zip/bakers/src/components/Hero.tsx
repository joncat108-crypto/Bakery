import { motion } from "framer-motion";
import { Sparkles, Phone } from "lucide-react";

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden border-b border-espresso/10">
      <div className="max-w-6xl mx-auto px-6 pt-14 pb-16 grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <span className="inline-flex items-center gap-2 text-berry font-semibold text-xs uppercase tracking-widest mb-5">
            <Sparkles size={14} /> Freshly baked, daily
          </span>
          <h1 className="font-display font-bold text-[2.6rem] leading-[1.02] sm:text-6xl">
            Cakes made
            <br />
            for your <em className="italic text-berry font-medium">real</em>
            <br />
            moments.
          </h1>
          <p className="mt-5 max-w-md text-espresso/70 leading-relaxed">
            Every cake at Bakers is made to order, by hand, the day it's delivered. Browse the menu,
            or just call us and tell us what you're picturing.
          </p>
          <div className="flex flex-wrap gap-3 mt-8">
            <a
              href="#shop"
              className="inline-flex items-center gap-2 bg-espresso text-cream rounded-full px-7 py-3.5 text-sm font-semibold hover:-translate-y-0.5 hover:shadow-soft transition-all"
            >
              Browse Cakes
            </a>
            <a
              href="#call"
              className="inline-flex items-center gap-2 border-[1.5px] border-espresso rounded-full px-7 py-3.5 text-sm font-semibold hover:bg-espresso hover:text-cream transition-colors"
            >
              <Phone size={15} /> Order by Phone
            </a>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, ease: "easeOut", delay: 0.15 }}
          className="relative aspect-[4/3.3] rounded-xl2 bg-gradient-to-br from-blush to-cream-deep flex items-center justify-center"
        >
          <span className="text-[9rem] sm:text-[11rem] drop-shadow-sm select-none">🎂</span>

          <div
            className="absolute -left-4 top-8 sm:-left-8 sm:top-10 bg-white rounded-2xl shadow-card px-4 py-3 flex items-center gap-2 animate-float"
            style={{ ["--tilt" as any]: "-4deg" }}
          >
            <span className="text-lg">⭐</span>
            <span className="text-sm font-semibold">4.9 rated by locals</span>
          </div>

          <div
            className="absolute -right-3 bottom-10 sm:-right-6 sm:bottom-14 bg-white rounded-2xl shadow-card px-4 py-3 flex items-center gap-2 animate-float"
            style={{ ["--tilt" as any]: "3deg", animationDelay: "1s" }}
          >
            <span className="text-lg">🚚</span>
            <span className="text-sm font-semibold">Same-day delivery</span>
          </div>

          <span className="absolute bottom-3 left-1/2 -translate-x-1/2 font-hand text-2xl text-berry rotate-[-2deg]">
            baked fresh today!
          </span>
        </motion.div>
      </div>
    </section>
  );
}
