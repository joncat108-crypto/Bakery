import { Search } from "lucide-react";

interface Props {
  query: string;
  onChange: (q: string) => void;
  resultCount: number;
}

export default function GlassSearchBar({ query, onChange, resultCount }: Props) {
  return (
    <div className="px-6 pt-4 pb-1 relative z-30">
      <div className="glass max-w-xl mx-auto rounded-full shadow-glass flex items-center pl-5 pr-2 py-2">
        <Search size={18} className="text-espresso/60 shrink-0" />
        <input
          type="text"
          value={query}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Search cakes — chocolate, red velvet, birthday..."
          aria-label="Search cakes"
          className="flex-1 bg-transparent border-none outline-none px-3 py-2.5 text-sm placeholder:text-espresso/45"
        />
        <button className="bg-espresso text-cream rounded-full px-5 py-2.5 text-sm font-semibold hover:bg-berry transition-colors">
          Search
        </button>
      </div>
      <p className="text-center text-xs text-espresso/55 mt-2 min-h-[16px]">
        {query.trim() ? `${resultCount} cake${resultCount !== 1 ? "s" : ""} found for "${query}"` : ""}
      </p>
    </div>
  );
}
