const STEPS = [
  {
    num: "01",
    title: "Pick your cake",
    body: "Search or browse, add it to your cart, or call us directly if you'd rather just describe it.",
  },
  {
    num: "02",
    title: "Choose how to pay",
    body: "Pay online with Razorpay, or choose Cash on Delivery — your call.",
  },
  {
    num: "03",
    title: "We bake & deliver",
    body: "Your cake is made fresh and delivered on your chosen date and address.",
  },
];

export default function HowItWorks() {
  return (
    <section id="how" className="bg-espresso text-cream">
      <div className="max-w-6xl mx-auto grid sm:grid-cols-3">
        {STEPS.map((s, i) => (
          <div
            key={s.num}
            className={`px-8 py-12 ${i < STEPS.length - 1 ? "sm:border-r border-b sm:border-b-0" : ""} border-cream/15`}
          >
            <div className="font-display font-bold text-3xl text-caramel">{s.num}</div>
            <h4 className="mt-3 font-semibold text-base">{s.title}</h4>
            <p className="mt-2 text-sm text-cream/70 leading-relaxed">{s.body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
