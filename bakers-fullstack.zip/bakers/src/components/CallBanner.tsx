import { Phone, MessageCircle } from "lucide-react";
import { telHref, waHref } from "@/lib/config";

export default function CallBanner() {
  return (
    <section id="call" className="max-w-6xl mx-auto px-6 py-14">
      <div className="bg-gradient-to-br from-berry to-berry-light text-cream rounded-xl2 p-9 sm:p-11 flex flex-wrap items-center justify-between gap-8">
        <div>
          <h3 className="font-display font-bold text-2xl sm:text-3xl max-w-md">
            Prefer to just talk it through?
          </h3>
          <p className="mt-2 text-sm text-cream/85 max-w-md leading-relaxed">
            Skip the forms — call us and tell us your cake, size, flavor, and address directly.
            We'll take it from there.
          </p>
        </div>
        <div className="flex gap-3 flex-wrap">
          <a
            href={telHref()}
            className="inline-flex items-center gap-2 bg-cream text-berry rounded-full px-6 py-3.5 text-sm font-semibold hover:-translate-y-0.5 transition-transform"
          >
            <Phone size={16} /> Call Now
          </a>
          <a
            href={waHref("Hi Bakers! I'd like to order a cake.")}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 border-[1.5px] border-cream rounded-full px-6 py-3.5 text-sm font-semibold hover:bg-cream hover:text-berry transition-colors"
          >
            <MessageCircle size={16} /> WhatsApp Us
          </a>
        </div>
      </div>
    </section>
  );
}
