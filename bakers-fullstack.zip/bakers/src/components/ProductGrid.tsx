import CategoryChips from "@/components/CategoryChips";
import ProductCard from "@/components/ProductCard";
import type { Product } from "@/types";

interface Props {
  products: Product[];
  categories: string[];
  category: string;
  onSelectCategory: (c: string) => void;
  loading: boolean;
  onAdd: (p: Product) => void;
  onCallOrder: (p: Product) => void;
}

export default function ProductGrid({
  products,
  categories,
  category,
  onSelectCategory,
  loading,
  onAdd,
  onCallOrder,
}: Props) {
  return (
    <section id="shop" className="max-w-6xl mx-auto px-6 py-16">
      <div className="flex flex-wrap justify-between items-end gap-5 mb-9">
        <h2 className="font-display font-bold text-3xl sm:text-4xl">Our Cakes</h2>
        <p className="text-espresso/60 text-sm max-w-xs">
          Search or filter to find the one — every item is baked fresh to order.
        </p>
      </div>

      <CategoryChips categories={categories} active={category} onSelect={onSelectCategory} />

      {loading ? (
        <div className="text-center py-16 text-espresso/50">Loading menu…</div>
      ) : products.length === 0 ? (
        <div className="text-center py-16 text-espresso/50">
          No cakes match that search. Try another term, or{" "}
          <a href="#call" className="text-berry font-semibold">
            call us
          </a>{" "}
          and we'll sort it out.
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} onAdd={onAdd} onCallOrder={onCallOrder} />
          ))}
        </div>
      )}
    </section>
  );
}
