const ITEMS = ["SMALL BATCH", "MADE TO ORDER", "SAME-DAY DELIVERY", "LOCALLY LOVED"];

export default function Marquee() {
  const row = [...ITEMS, ...ITEMS];
  return (
    <div className="bg-espresso text-cream overflow-hidden py-3 border-y border-cream/10">
      <div className="flex gap-14 whitespace-nowrap w-max animate-marquee">
        {[...row, ...row].map((item, i) => (
          <span key={i} className="text-sm font-bold tracking-widest">
            {item} <span className="text-caramel">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}
