import { CONFIG } from "@/lib/config";

export default function Footer() {
  return (
    <footer className="bg-white border-t border-espresso/10 pt-12 pb-7">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-8 pb-8">
          <div>
            <div className="font-display font-black text-2xl mb-2">
              Bakers<span className="text-berry">.</span>
            </div>
            <p className="text-sm text-espresso/60 max-w-[240px]">
              Handmade cakes, baked fresh to order. Local bakery, real ingredients, no shortcuts.
            </p>
          </div>
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wide mb-3">Shop</h4>
            <ul className="space-y-2 text-sm text-espresso/60">
              <li><a href="#shop" className="hover:text-berry">All Cakes</a></li>
              <li><a href="#shop" className="hover:text-berry">Birthday</a></li>
              <li><a href="#shop" className="hover:text-berry">Wedding</a></li>
              <li><a href="#shop" className="hover:text-berry">Custom Orders</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wide mb-3">Help</h4>
            <ul className="space-y-2 text-sm text-espresso/60">
              <li><a href="#how" className="hover:text-berry">Delivery Info</a></li>
              <li><a href="#call" className="hover:text-berry">Order by Phone</a></li>
              <li><a href="#" className="hover:text-berry">Returns Policy</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wide mb-3">Contact</h4>
            <ul className="space-y-2 text-sm text-espresso/60">
              <li>{CONFIG.bakeryPhone}</li>
              <li><a href="#" className="hover:text-berry">Instagram</a></li>
              <li><a href="#" className="hover:text-berry">Facebook</a></li>
            </ul>
          </div>
        </div>
        <div className="flex flex-wrap justify-between gap-2 pt-5 border-t border-espresso/10 text-xs text-espresso/45">
          <span>© 2026 Bakers. All rights reserved.</span>
          <span>Site maintained by your web partner</span>
        </div>
      </div>
    </footer>
  );
}
