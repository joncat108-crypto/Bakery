interface Props {
  categories: string[];
  active: string;
  onSelect: (c: string) => void;
}

export default function CategoryChips({ categories, active, onSelect }: Props) {
  return (
    <div className="flex gap-2 flex-wrap mb-8">
      {categories.map((c) => (
        <button
          key={c}
          onClick={() => onSelect(c)}
          className={`px-[18px] py-2.5 rounded-full text-sm font-semibold border transition-colors ${
            active === c
              ? "bg-espresso text-cream border-espresso"
              : "bg-white text-espresso/65 border-espresso/15 hover:border-espresso/40"
          }`}
        >
          {c}
        </button>
      ))}
    </div>
  );
}
