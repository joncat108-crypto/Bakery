import { Phone, MessageCircle } from "lucide-react";
import ModalShell from "@/components/ModalShell";
import { telHref, waHref } from "@/lib/config";
import type { Product } from "@/types";

interface Props {
  product: Product | null;
  onClose: () => void;
}

export default function CallToOrderModal({ product, onClose }: Props) {
  return (
    <ModalShell open={!!product} onClose={onClose}>
      <h3 className="font-display font-bold text-xl mb-1">
        Order "{product?.name}" by Phone
      </h3>
      <p className="text-sm text-espresso/60 mb-6">
        Just call or WhatsApp us — tell us the cake, size, date and your address directly. No forms needed.
      </p>
      <a
        href={telHref()}
        className="flex items-center justify-center gap-2 w-full bg-espresso text-cream rounded-full py-3.5 font-semibold text-sm mb-2.5 hover:bg-berry transition-colors"
      >
        <Phone size={16} /> Call Bakers Now
      </a>
      <a
        href={waHref(`Hi Bakers! I'd like to order: ${product?.name ?? ""}`)}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center gap-2 w-full border-[1.5px] border-espresso rounded-full py-3.5 font-semibold text-sm hover:bg-espresso hover:text-cream transition-colors"
      >
        <MessageCircle size={16} /> Message on WhatsApp
      </a>
    </ModalShell>
  );
}
