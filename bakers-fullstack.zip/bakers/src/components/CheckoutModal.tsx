import { useState } from "react";
import ModalShell from "@/components/ModalShell";
import { useCart } from "@/hooks/useCart";
import { useAuth } from "@/hooks/useAuth";
import { CONFIG } from "@/lib/config";
import { saveOrder } from "@/lib/orders";
import type { PaymentMethod } from "@/types";

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function CheckoutModal({ open, onClose }: Props) {
  const { cart, total, clearCart } = useCart();
  const { user } = useAuth();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [payMethod, setPayMethod] = useState<PaymentMethod>("razorpay");
  const [message, setMessage] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handlePlaceOrder() {
    if (!name.trim() || !phone.trim() || !address.trim()) {
      setMessage({ type: "err", text: "Please fill in your name, phone, and address." });
      return;
    }
    setSubmitting(true);
    setMessage(null);

    const basePayload = {
      user_id: user?.id ?? null,
      customer_name: name,
      phone,
      address,
      items: cart,
      total: total(),
    };

    if (payMethod === "cod") {
      await saveOrder({ ...basePayload, payment_method: "cod", status: "pending_cod" });
      setMessage({ type: "ok", text: `Order placed! We'll call ${phone} to confirm delivery details.` });
      clearCart();
      setSubmitting(false);
      setTimeout(onClose, 1800);
      return;
    }

    // Razorpay flow
    if (!CONFIG.razorpayKeyId) {
      setMessage({
        type: "err",
        text: "Online payment isn't set up yet — please choose Cash on Delivery, or contact us to enable it.",
      });
      setSubmitting(false);
      return;
    }

    const rzp = new window.Razorpay({
      key: CONFIG.razorpayKeyId,
      amount: total() * 100,
      currency: "INR",
      name: "Bakers",
      description: "Cake order",
      prefill: { name, contact: phone },
      theme: { color: "#2B1810" },
      handler: async (response: { razorpay_payment_id: string }) => {
        await saveOrder({
          ...basePayload,
          payment_method: "razorpay",
          status: "paid",
          razorpay_payment_id: response.razorpay_payment_id,
        });
        setMessage({ type: "ok", text: "Payment successful! Your order is confirmed." });
        clearCart();
        setTimeout(onClose, 1800);
      },
    });
    rzp.on("payment.failed", () => {
      setMessage({ type: "err", text: "Payment failed. You can try again or choose Cash on Delivery." });
    });
    rzp.open();
    setSubmitting(false);
  }

  return (
    <ModalShell open={open} onClose={onClose} wide>
      <h3 className="font-display font-bold text-xl mb-1">Checkout</h3>
      <p className="text-sm text-espresso/60 mb-4">
        Total: <strong className="text-espresso">₹{total()}</strong>
      </p>

      {message && (
        <div
          className={`text-sm rounded-lg px-3 py-2.5 mb-4 ${
            message.type === "ok" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
          }`}
        >
          {message.text}
        </div>
      )}

      <div className="space-y-3.5 mb-4">
        <Field label="Full Name" value={name} onChange={setName} placeholder="Your name" />
        <Field label="Phone Number" value={phone} onChange={setPhone} placeholder="10-digit mobile number" />
        <div>
          <label className="block text-xs font-semibold text-espresso/60 mb-1.5">Delivery Address</label>
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Full delivery address"
            rows={3}
            className="w-full px-3.5 py-3 rounded-xl border border-espresso/15 text-sm resize-y"
          />
        </div>
      </div>

      <label className="block text-xs font-semibold text-espresso/60 mb-2">Payment Method</label>
      <div className="space-y-2 mb-5">
        <PayOption
          selected={payMethod === "razorpay"}
          onClick={() => setPayMethod("razorpay")}
          title="Pay Online (Razorpay)"
          subtitle="Card, UPI, Netbanking — secure checkout"
        />
        <PayOption
          selected={payMethod === "cod"}
          onClick={() => setPayMethod("cod")}
          title="Cash on Delivery"
          subtitle="Pay when your cake arrives"
        />
      </div>

      <button
        onClick={handlePlaceOrder}
        disabled={submitting}
        className="w-full bg-espresso text-cream rounded-full py-3.5 font-semibold text-sm hover:bg-berry transition-colors disabled:opacity-60"
      >
        {submitting ? "Placing order…" : "Place Order"}
      </button>
    </ModalShell>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
}) {
  return (
    <div>
      <label className="block text-xs font-semibold text-espresso/60 mb-1.5">{label}</label>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-3.5 py-3 rounded-xl border border-espresso/15 text-sm"
      />
    </div>
  );
}

function PayOption({
  selected,
  onClick,
  title,
  subtitle,
}: {
  selected: boolean;
  onClick: () => void;
  title: string;
  subtitle: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 border-[1.5px] rounded-xl p-3.5 text-left transition-colors ${
        selected ? "border-berry bg-berry/5" : "border-espresso/15"
      }`}
    >
      <span
        className={`w-4 h-4 rounded-full border-2 shrink-0 ${selected ? "border-berry bg-berry" : "border-espresso/30"}`}
      />
      <span>
        <span className="block text-sm font-semibold">{title}</span>
        <span className="block text-xs text-espresso/55">{subtitle}</span>
      </span>
    </button>
  );
}
