import ModalShell from "@/components/ModalShell";
import { useCart } from "@/hooks/useCart";

interface Props {
  open: boolean;
  onClose: () => void;
  onCheckout: () => void;
}

export default function CartModal({ open, onClose, onCheckout }: Props) {
  const { cart, changeQty, total } = useCart();

  return (
    <ModalShell open={open} onClose={onClose}>
      <h3 className="font-display font-bold text-xl mb-5">Your Cart</h3>

      {cart.length === 0 ? (
        <p className="text-center text-espresso/50 py-8 text-sm">Your cart is empty.</p>
      ) : (
        <>
          <div className="space-y-0 mb-4">
            {cart.map((line) => (
              <div key={line.id} className="flex items-center justify-between py-2.5 border-b border-espresso/10 text-sm">
                <span className="font-medium">{line.name}</span>
                <div className="flex items-center gap-2.5">
                  <button
                    onClick={() => changeQty(line.id, -1)}
                    className="w-6 h-6 rounded-full border border-espresso/20 text-xs"
                    aria-label={`Decrease ${line.name}`}
                  >
                    −
                  </button>
                  <span className="w-4 text-center">{line.qty}</span>
                  <button
                    onClick={() => changeQty(line.id, 1)}
                    className="w-6 h-6 rounded-full border border-espresso/20 text-xs"
                    aria-label={`Increase ${line.name}`}
                  >
                    +
                  </button>
                  <span className="font-semibold ml-1 w-14 text-right">₹{line.price * line.qty}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="flex justify-between font-bold text-lg my-4">
            <span>Total</span>
            <span>₹{total()}</span>
          </div>
          <button
            onClick={onCheckout}
            className="w-full bg-espresso text-cream rounded-full py-3.5 font-semibold text-sm hover:bg-berry transition-colors"
          >
            Proceed to Checkout
          </button>
        </>
      )}
    </ModalShell>
  );
}
