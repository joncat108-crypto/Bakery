import { ShoppingBag, User, Menu } from "lucide-react";
import { useState } from "react";
import { useCart } from "@/hooks/useCart";

interface Props {
  onOpenCart: () => void;
  onOpenAccount: () => void;
}

export default function Header({ onOpenCart, onOpenAccount }: Props) {
  const count = useCart((s) => s.count());
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-cream/90 backdrop-blur-md border-b border-espresso/10">
      <nav className="max-w-6xl mx-auto flex items-center gap-6 px-6 py-4">
        <a href="#top" className="font-display font-black text-2xl tracking-tight">
          Bakers<span className="text-berry">.</span>
        </a>

        <div className="hidden md:flex items-center gap-7 font-semibold text-sm mr-auto ml-4">
          <a href="#shop" className="hover:text-berry transition-colors">
            Shop
          </a>
          <a href="#how" className="hover:text-berry transition-colors">
            How it Works
          </a>
          <a href="#call" className="hover:text-berry transition-colors">
            Order by Phone
          </a>
        </div>
        <div className="md:hidden mr-auto" />

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenAccount}
            aria-label="Account"
            className="w-11 h-11 rounded-full border border-espresso/15 bg-white flex items-center justify-center hover:border-berry hover:text-berry transition-colors"
          >
            <User size={18} />
          </button>
          <button
            onClick={onOpenCart}
            aria-label="Cart"
            className="relative w-11 h-11 rounded-full border border-espresso/15 bg-white flex items-center justify-center hover:border-berry hover:text-berry transition-colors"
          >
            <ShoppingBag size={18} />
            {count > 0 && (
              <span className="absolute -top-1 -right-1 bg-berry text-cream text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
                {count}
              </span>
            )}
          </button>
          <button
            className="md:hidden w-11 h-11 rounded-full border border-espresso/15 bg-white flex items-center justify-center"
            aria-label="Menu"
            onClick={() => setMobileOpen((v) => !v)}
          >
            <Menu size={18} />
          </button>
        </div>
      </nav>

      {mobileOpen && (
        <div className="md:hidden flex flex-col gap-1 px-6 pb-4 font-semibold text-sm">
          <a href="#shop" onClick={() => setMobileOpen(false)} className="py-2">
            Shop
          </a>
          <a href="#how" onClick={() => setMobileOpen(false)} className="py-2">
            How it Works
          </a>
          <a href="#call" onClick={() => setMobileOpen(false)} className="py-2">
            Order by Phone
          </a>
        </div>
      )}
    </header>
  );
}
