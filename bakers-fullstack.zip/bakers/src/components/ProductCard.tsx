import { motion } from "framer-motion";
import { Phone } from "lucide-react";
import type { Product } from "@/types";

interface Props {
  product: Product;
  index: number;
  onAdd: (p: Product) => void;
  onCallOrder: (p: Product) => void;
}

export default function ProductCard({ product, index, onAdd, onCallOrder }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.4, delay: Math.min(index * 0.05, 0.3) }}
      className="ticket-edge bg-white rounded-2xl overflow-hidden border border-espresso/10 hover:shadow-card hover:-translate-y-1 transition-all duration-300"
    >
      <div className="aspect-[4/3] bg-gradient-to-br from-cream-deep to-blush flex items-center justify-center relative">
        <span className="absolute top-3 left-3 bg-white/90 rounded-full px-3 py-1 text-[11px] font-bold text-berry">
          {product.stock > 0 ? `${product.stock} left` : "Sold out"}
        </span>
        <span className="text-6xl">{product.emoji}</span>
      </div>
      <div className="p-4 pb-6 flex flex-col gap-1.5">
        <span className="text-[11px] font-bold uppercase tracking-wide text-caramel">{product.category}</span>
        <h3 className="font-display font-semibold text-lg leading-tight">{product.name}</h3>
        <p className="text-[13px] text-espresso/60 leading-snug">{product.description}</p>
        <div className="flex items-center justify-between mt-3">
          <span className="font-bold text-lg">₹{product.price}</span>
          <div className="flex gap-2">
            <button
              onClick={() => onCallOrder(product)}
              aria-label={`Call to order ${product.name}`}
              className="w-9 h-9 rounded-full border border-espresso/15 flex items-center justify-center hover:border-berry hover:text-berry transition-colors"
            >
              <Phone size={15} />
            </button>
            <button
              onClick={() => onAdd(product)}
              disabled={product.stock <= 0}
              className="bg-espresso text-cream rounded-full px-4 py-2 text-xs font-semibold disabled:opacity-40 hover:bg-berry transition-colors"
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
