import { useState } from "react";
import Header from "@/components/Header";
import GlassSearchBar from "@/components/GlassSearchBar";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import ProductGrid from "@/components/ProductGrid";
import HowItWorks from "@/components/HowItWorks";
import CallBanner from "@/components/CallBanner";
import Footer from "@/components/Footer";
import CartModal from "@/components/CartModal";
import CheckoutModal from "@/components/CheckoutModal";
import AccountModal from "@/components/AccountModal";
import CallToOrderModal from "@/components/CallToOrderModal";
import { useCart } from "@/hooks/useCart";
import { useProducts } from "@/hooks/useProducts";
import type { Product } from "@/types";

export default function App() {
  const { products, categories, category, setCategory, query, setQuery, loading } = useProducts();
  const addToCart = useCart((s) => s.addToCart);

  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const [callProduct, setCallProduct] = useState<Product | null>(null);

  return (
    <div className="relative min-h-screen">
      <div className="grain-overlay" />
      <div className="bg-espresso text-cream text-center text-xs py-2 px-3 tracking-wide">
        🎂 Free delivery on orders over ₹999 · Same-day slots available
      </div>

      <Header onOpenCart={() => setCartOpen(true)} onOpenAccount={() => setAccountOpen(true)} />
      <GlassSearchBar query={query} onChange={setQuery} resultCount={products.length} />

      <main>
        <Hero />
        <Marquee />
        <ProductGrid
          products={products}
          categories={categories}
          category={category}
          onSelectCategory={setCategory}
          loading={loading}
          onAdd={addToCart}
          onCallOrder={setCallProduct}
        />
        <HowItWorks />
        <CallBanner />
      </main>

      <Footer />

      <CartModal
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        onCheckout={() => {
          setCartOpen(false);
          setCheckoutOpen(true);
        }}
      />
      <CheckoutModal open={checkoutOpen} onClose={() => setCheckoutOpen(false)} />
      <AccountModal open={accountOpen} onClose={() => setAccountOpen(false)} />
      <CallToOrderModal product={callProduct} onClose={() => setCallProduct(null)} />
    </div>
  );
}
