-- Bakers database schema
-- Run this in Supabase → SQL Editor

create table if not exists products (
  id bigint generated always as identity primary key,
  name text not null,
  category text not null,
  price integer not null,
  emoji text default '🎂',
  image_url text,
  description text,
  stock integer default 10,
  created_at timestamp with time zone default now()
);

create table if not exists orders (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id),
  customer_name text,
  phone text,
  address text,
  items jsonb,
  total integer,
  payment_method text,
  status text,
  razorpay_payment_id text,
  created_at timestamp with time zone default now()
);

alter table products enable row level security;
create policy "Public can view products" on products
  for select using (true);

alter table orders enable row level security;
create policy "Anyone can insert an order" on orders
  for insert with check (true);
create policy "Users see their own orders" on orders
  for select using (auth.uid() = user_id);

-- Sample rows to get started — delete or edit freely
insert into products (name, category, price, emoji, description, stock) values
  ('Classic Chocolate Truffle', 'Chocolate', 899, '🍫', 'Rich Belgian chocolate sponge, ganache-layered, chocolate shavings on top.', 12),
  ('Red Velvet Delight', 'Signature', 999, '❤️', 'Classic red velvet with smooth cream cheese frosting.', 8),
  ('Fresh Fruit Gateau', 'Fruit', 1099, '🍓', 'Vanilla sponge layered with fresh seasonal fruit and light cream.', 6),
  ('Birthday Sprinkle Cake', 'Birthday', 799, '🎉', 'Vanilla funfetti sponge, buttercream, loaded with sprinkles.', 15);
